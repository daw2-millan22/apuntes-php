<?php

abstract class AbstractZona {
  
  private $nombre;
  private $superficie;
  private $poblacion;
  private $zonas = array();

  
  public function add(AbstractZona  $zona) {
     array_push($this->zonas, $zona);
  }
        
  public function hasChildren() {
    return (bool)(count($this->zonas) > 0);
  }
    
  public function getChild($i) {
    return $this->zonas[i];
  }
    
  public function getDescription() {
    echo "- one " . $this->getNombre();
    if ($this->hasChildren()) {
      echo " which includes:<br>";
      foreach($this->zonas as $zona) {
         echo "<table cellspacing=5 border=0><tr><td>&nbsp;&nbsp;&nbsp;</td><td>-";
         $zona->getDescription();
         echo "</td></tr></table>";
      }        
    }
  } 

///////////////////////////////////////////////////
 public function setNombre($nombre) {
   $this->nombre = $nombre;
 }
 public function getNombre() {
   return $this->nombre;
 }
////////////////////////////////////////////////////
 public function setSuperficie($superficie) {
    $this->superficie = $superficie;
 }
 public function getSuperficie() {
   return $this->superficie;
  }
/////////////////////////////////////////////////////
 public function setPoblacion($poblacion) {
    $this->poblacion = $poblacion;
 }
 public function getPoblacion() {
   return $this->poblacion;
 }
/////////////////////////////////////////////////////
 public function getZonas() {
    return $this->zonas;
 }
}


///Clases
/////////////////////////////////////////////////////////////
class Continente extends AbstractZona {
    function __construct($nombre, $superficie, $poblacion) {
      parent::setNombre($nombre);
      parent::setSuperficie($superficie);
      parent::setPoblacion($poblacion);
      
    }   
    
    /////////////////////////////////////////////////////CLASES SUMAR
    public function sumarPoblacion() {
      $total = 0;
      if ($this->hasChildren()) {
        foreach($this->getZonas() as $zona ) {
          if(get_class($zona) == "Pais"){
            $poblacionCP = $zona->sumarPoblacionCP();  
            // echo "<br>La poblacion total de los pueblos y ciudades ".$this->getNombre()." es ". $poblacionCP. "<br><br>";   
            $total = $total + $poblacionCP;
          }
        }   
      }
      echo "La poblacion total de los paises de ".$this->getNombre()." es ".$total."<br><br>";
    }

    public function sumarSuperficie() {
      $total = 0;
      if ($this->hasChildren()) {
        foreach($this->getZonas() as $zona ) {
          if(get_class($zona) == "Pais"){
            $superficieCP = $zona->sumarSuperficieCP();
            $total = $total + $superficieCP;
          }
        }        
      }
      echo "La superficie total de los paises de ".$this->getNombre()." es ".$total."<br><br>";

    }
}

class Pais extends AbstractZona {
    function __construct($nombre, $superficie, $poblacion) {
      parent::setNombre($nombre);
      parent::setSuperficie($superficie);
      parent::setPoblacion($poblacion);
    }   
  public function sumarPoblacionCP(){
    $poblacionTotal = 0;

    if ($this->hasChildren()) {
      foreach($this->getZonas() as $zona) {
        $poblacionTotal = $poblacionTotal + $zona->getPoblacion();
      } 
    // echo "<br>La poblacion total de los pueblos y ciudades ".$this->getNombre()." es ". $poblacionTotal. "<br><br>";   
    }
    // echo "a". $poblacionTotal;
    return $poblacionTotal;
  }   

  public function sumarSuperficieCP(){
    $superficieTotal = 0;

    if ($this->hasChildren()) {
      foreach($this->getZonas() as $zona) {
        $superficieTotal = $superficieTotal + $zona->getSuperficie();
      } 
     echo "<br>La superficie total de los pueblos y ciudades ".$this->getNombre()." es ". $superficieTotal."<br><br>";   
    }
    return $superficieTotal;
  }
    
}

class Ciudad extends AbstractZona {
    function __construct($nombre, $superficie, $poblacion) {
      parent::setNombre($nombre);
      parent::setSuperficie($superficie);
      parent::setPoblacion($poblacion);
    }      
}

class Pueblo extends AbstractZona {
    function __construct($nombre, $superficie, $poblacion) {
      parent::setNombre($nombre);
      parent::setSuperficie($superficie);
      parent::setPoblacion($poblacion);
    }      
}


///////////////////////////////////////////////////////////// INSTANCIO CLASES


$continente1 = new Continente("Africa", 5000, 2000);
$pais1 = new Pais("Nigeria", 3000, 1000);
$ciudad1 = new Ciudad("Lagos", 2000, 500);
$ciudad11 = new Ciudad("Abuya", 1500, 200);
$pueblo1 = new Pueblo("Kano", 1000, 100);

$pais3 = new Pais("AA", 3000, 1000);
$ciudad3 = new Ciudad("BB", 1000, 1);
$ciudad3 = new Ciudad("CC", 1100, 1);
$pueblo3 = new Pueblo("DD", 500, 1);

$continente1->add($pais1);
$pais1->add($ciudad1);
$pais1->add($ciudad11);
$pais1->add($pueblo1);

$continente1->add($pais3);
$pais3->add($ciudad3);
$pais3->add($ciudad3);
$pais3->add($pueblo3);


$continente2 = new Continente("Europa", 6000, 3000);
$pais2 = new Pais("Alemania", 4000, 2000);
$ciudad2 = new Ciudad("Berlin", 3000, 1000);
$pueblo2 = new Pueblo("Munich", 2000, 200);
$pueblo22 = new Pueblo("Hamelin", 1000, 100);


$continente2->add($pais2);
$pais2->add($ciudad2);
$pais2->add($pueblo2);
$pais2->add($pueblo22);

$continente1->getDescription();
$continente1->sumarPoblacion();
$continente1->sumarSuperficie();

$continente2->getDescription();
$continente2->sumarPoblacion();
$continente2->sumarSuperficie();

// $continente2->getDescription();



?>