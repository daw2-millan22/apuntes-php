<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
		//connect to MySQL
		$db = mysqli_connect('localhost', 'root', 'root') or die ('Unable to connect. Check your connection parameters.');

		$query = 'CREATE DATABASE IF NOT EXISTS gent';
		mysqli_query($db,$query) or die(mysqli_error($db));

		mysqli_select_db($db,'gent') or die(mysqli_error($db));
		//create the movie table
		$query = 'CREATE TABLE gent (
		        gent_id        INTEGER UNSIGNED  NOT NULL AUTO_INCREMENT, 
		        nom      VARCHAR(255)      NOT NULL,
		        password      VARCHAR(255)      NOT NULL,  
		        edad INTEGER UNSIGNED  NOT NULL DEFAULT 0,

		        PRIMARY KEY (gent_id)
		    ) 
		    ENGINE=MyISAM';
  		mysqli_query($db,$query) or die (mysqli_error($db));
	?>
</body>
</html>