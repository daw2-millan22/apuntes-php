<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<form method="post" action="02verificar.php">
		<p>Introdueix el teu nom: 
			<input type="text" name="nom"/>
		</p>
		<p>Introdueix tu contraseña: 
			<input type="password" name="pass"/>
		</p>
		<p>
   			Quina edad tens?:
   			<input type="number" name="edad" id="edadUser">
   		</p>
		<input type="submit" name="submit" value="Submit"/>
	</form>
	
</body>
</html>