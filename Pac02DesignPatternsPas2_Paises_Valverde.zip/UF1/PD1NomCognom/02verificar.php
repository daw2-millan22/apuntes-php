<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	
	<?php
		$nombre= $_POST['nom'];
		$contrasenia=$_POST['pass'];
		$anios=$_POST['edad'];

		if($anios<18){
			echo "Lo siento eres menor de edad no puedes acceder a la pagina <br>";
		}else{
			$db = mysqli_connect('localhost', 'root', 'root') or die ('No has conseguido hacer conexion');

			mysqli_select_db($db,'gent') or die(mysqli_error($db));

			$insert= "INSERT INTO gent (nom, password, edad)
			 VALUES
			 	('$nombre', '$contrasenia', '$anios')";

			mysqli_query($db,$insert) or die(mysqli_error($db));
			if(mysqli_error($db)==null){
				echo "se han introducido los datos";
			}
		}
		setcookie("nom", $_POST['nom'], time() + 6000);

		echo "<a href='02cookie.php'>mira el mensaje</a><br>";
		echo "<a href='02form.php'>introduce otro</a><br>";
		echo "<a href='04llistat.php'>mirar tabla</a>";
	?>
</body>
</html>