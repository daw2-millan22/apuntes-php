<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
	session_start();
	$numA=$_POST['numA'];
	$numB=$_POST['numB'];
	$_SESSION['mensaje']= "'$numA'x'$numB'x'$numA'='$numB'x'$numA'x'$numA'";
	echo "<a href='03mensaje.php'>vemos el mensaje</a>";
	?>
</body>
</html>