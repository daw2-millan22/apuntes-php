<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		tr, td{
			border: solid 1px;
			border-collapse: inherit;
		}
	</style>
</head>
<body>
	<?php

		$servidor="localhost";
        $dbNombre="gent";
        $usuario="root";
        $contrasenia="root";

        $conexion=mysqli_connect($servidor, $usuario, $contrasenia)or die('no has conectado a la base de datos');

        mysqli_select_db($conexion, $dbNombre) or die(mysqli_error($conexion));

        $consulta='SELECT * FROM gent';

        $resultado=mysqli_query($conexion, $consulta);


        echo "<table>";

        	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
        		echo "<tr>";
        		echo "<td>".$fila['nom']."</td><td>".$fila['password']."</td><td>".$fila['edad']."</td>";
        		echo "</tr>";
        	}

        echo "</table>";
	?>
</body>
</html>