<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		tr, td{
			border: solid 1px;
			border-collapse: collapse;
		}
	</style>
</head>
<body>
	<?php 
		$servidor="localhost";
        $dbNombre="gent";
        $usuario="root";
        $contrasenia="root";
        $radiobutton=$_POST['ordenar'];

        $conexion=mysqli_connect($servidor, $usuario, $contrasenia)or die('no has conectado a la base de datos');

        mysqli_select_db($conexion, $dbNombre) or die(mysqli_error($conexion));

        if($_POST['ordenar']=="edad"){
        	$consulta='SELECT * FROM gent ORDER BY edad ';
        }else{
        	$consulta='SELECT * FROM gent ORDER BY nom';
        }
		
		

		$resultado=mysqli_query($conexion, $consulta);

		$fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC);

		echo "<table>";

        	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
        		echo "<tr>";
        		echo "<td>".$fila['nom']."</td><td>".$fila['password']."</td><td>".$fila['edad']."</td>";
        		echo "</tr>";
        	}

        echo "</table>";
	?>
</body>
</html>
