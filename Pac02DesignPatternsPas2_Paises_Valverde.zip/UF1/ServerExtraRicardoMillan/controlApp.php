<?php
	session_start();
	$nick1=$_POST['nick'];
	$nom1=$_POST['nom'];
	$contrasenya1=$_POST['contrasenya'];

	$_SESSION['nick']=$nick1;
	$_SESSION['nom']=$nom1;
	$_SESSION['contrasenya']=$contrasenya1;

	$db = mysqli_connect('localhost', 'root', 'root') or die ('Unable to connect. Check your connection parameters.');

	//make sure our recently created database is the active one
	mysqli_select_db($db,'userricardomillan') or die(mysqli_error($db));


	$query = 'SELECT * FROM usuari
			WHERE nick like "'.$nick1.'" AND 
			nom like "'.$nom1.'" AND 
			contrasenya like "'.$contrasenya1.'"';
  	mysqli_query($db,$query) or die (mysqli_error($db));
  	$resultado=mysqli_query($db, $query);

  	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
		$nick=$fila['nick'];
		$nom=$fila['nom'];
		$contrasenya=$fila['contrasenya'];
	}
	if(($nick1== $nick) and ($nom1 == $nom) and ($contrasenya1 == $contrasenya)){
		$_SESSION['authuser'] = 1;
		echo'Bienvenido  ';
		echo $_SESSION['nom'];
	}
	else{
		echo 'Lo siento pero el nombre de usuario o la contraseña estan incorrectos';
		exit();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<p>¿QUE QUIERES HACER?</p>
	<br>
	<a href="listaUsuarios.php">Listar todos los usuarios</a><br>
	<a href="editarUsuarios.php">editar  usuarios</a><br>
	<a href="eliminarUsuarios.php">Eliminar un usuario y sus aplicaciones</a><br>
	<a href="listaApps.php">Listar todas las aplicaciones</a><br>
	<a href="insertinto.php">Añadir una app</a><br>
</body>
</html>