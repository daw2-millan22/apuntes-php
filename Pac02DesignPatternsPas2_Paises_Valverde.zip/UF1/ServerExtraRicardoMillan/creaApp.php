<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
		//connect to MySQL
		$db = mysqli_connect('localhost', 'root', 'root') or die ('Unable to connect. Check your connection parameters.');

		$query = 'CREATE DATABASE IF NOT EXISTS userRicardoMillan';
		mysqli_query($db,$query) or die(mysqli_error($db));

		mysqli_select_db($db,'userRicardoMillan') or die(mysqli_error($db));
		//create the movie table
		$query = 'CREATE TABLE Usuari (
    		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
   			nick VARCHAR(50) NOT NULL UNIQUE,
    		nom VARCHAR(50) NOT NULL,
    		cognom VARCHAR(50) NOT NULL,
    		contrasenya VARCHAR(255) NOT NULL,
    		dataCreacio DATETIME DEFAULT CURRENT_TIMESTAMP
			)';
  		mysqli_query($db,$query) or die (mysqli_error($db));

  		$query = 'CREATE TABLE Aplicacio (
   					 id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
   					 nom VARCHAR(50) NOT NULL UNIQUE,
   					 versio VARCHAR(50) NOT NULL,
					 cfUsuari INT NOT NULL,
   					 dataInstalacio DATETIME DEFAULT CURRENT_TIMESTAMP)';
  		mysqli_query($db,$query) or die (mysqli_error($db));
	?>
</body>
</html>