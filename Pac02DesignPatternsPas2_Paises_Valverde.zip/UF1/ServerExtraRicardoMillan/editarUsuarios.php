<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>editar usuarios</h1>
	<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	

  	//make sure our recently created database is the active one
	mysqli_select_db($db,'userricardomillan') or die(mysqli_error($db));

	$query='SELECT nom FROM usuari';
	$resultado=mysqli_query($db, $query);
	mysqli_query($db,$query) or die (mysqli_error($db));

	?>
	
	<form action="editarUsuarios2.php" method="post">
		<p>Que usuario Quieres editar?</p>
		<select name="nom" id="nom">
			<?php 
				while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
					echo "<option value=".$fila['nom'].">".$fila['nom']."</option>";
				}
			?>
		</select>
		<input type="submit">
	</form>
	
</body>
</html>