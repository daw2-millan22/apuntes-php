<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	

  	//make sure our recently created database is the active one
	mysqli_select_db($db,'userricardomillan') or die(mysqli_error($db));

	$nom=$_POST['nom'];
	$nick=$_POST['nick'];
	$contrasenya=$_POST['contrasenya'];
	$id=$_POST['id'];

	$query2='UPDATE usuari SET nom = "'.$nom.'", nick = "'.$nick.'", contrasenya = "'.$contrasenya.'" WHERE id = '.$id;


	$resultado2=mysqli_query($db, $query2);
	mysqli_query($db,$query2) or die (mysqli_error($db));

	echo "<a href='listaUsuarios.php'>lista de usuarios</a>";



?>