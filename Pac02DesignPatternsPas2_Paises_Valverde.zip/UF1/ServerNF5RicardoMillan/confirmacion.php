<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Estas seguro ?</h1>
	<form action="delete.php" method="post">
		<input type="submit" value="si">
		<?php echo  '<input  type="hidden" name="title" value="'.$_POST['title'].'">' ?>
	</form>
	<form action="default.html">
		<input type="submit" value="no">
	</form>
</body>
</html>