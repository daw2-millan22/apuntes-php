<?php
//connect to MySQL
$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');

//create the main database if it doesn't already exist
$query = 'CREATE DATABASE IF NOT EXISTS BookWeb';
mysqli_query($db,$query) or die(mysqli_error($db));

//make sure our recently created database is the active one
mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

//create the book table
$query = 'CREATE TABLE Book (
        idBook        INTEGER UNSIGNED  NOT NULL AUTO_INCREMENT, 
        isbn      VARCHAR(255)      NOT NULL, 
        author  INTEGER,
        title      VARCHAR(255)      NOT NULL, 
        visit INTEGER, 
        year  INTEGER, 

        PRIMARY KEY (idBook)
    ) 
    ENGINE=MyISAM';
mysqli_query($db,$query) or die (mysqli_error($db));

//create the movietype table
$query = 'CREATE TABLE People ( 
        idPeople        INTEGER UNSIGNED  NOT NULL AUTO_INCREMENT, 
        name     VARCHAR(100)     NOT NULL,
        address         VARCHAR(100)     NOT NULL,
        age      INTEGER, 
        PRIMARY KEY (idPeople) 
    ) 
    ENGINE=MyISAM';
mysqli_query($db,$query) or die(mysqli_error($db));


echo 'BookWeb database successfully created!';
?>
