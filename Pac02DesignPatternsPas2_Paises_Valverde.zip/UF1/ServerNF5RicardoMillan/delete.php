<?php 
	$db = mysqli_connect('localhost', 'root', 'root') or 
   	die ('Unable to connect. Check your connection parameters.');
	
  	//make sure our recently created database is the active one
  	mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

  	echo $_POST['title'];

	$consulta='DELETE FROM book WHERE title LIKE "'.$_POST['title'].'%"';
	$resultado=mysqli_query($db, $consulta);
	mysqli_query($db,$consulta) or die (mysqli_error($db));

?>