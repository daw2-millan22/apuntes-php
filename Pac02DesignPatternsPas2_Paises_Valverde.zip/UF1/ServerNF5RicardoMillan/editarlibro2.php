<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php 
	session_start();


	$nom=$_POST['nom'];

	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	

  	//make sure our recently created database is the active one
	mysqli_select_db($db,'userricardomillan') or die(mysqli_error($db));

	$query='SELECT * FROM usuari WHERE nom LIKE "'.$nom.'"';
	$resultado=mysqli_query($db, $query);
	mysqli_query($db,$query) or die (mysqli_error($db));

	
	?>
	
	<form action="update.php" method="post">
		<p>nick</p>
		<?php echo '<input type="text" name="title" value="'.$_POST['libro'].'">'; ?>
		<br>
		<p>nom</p>
		
			<?php 
				while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
					echo "<p>nom</p>";
					echo '<input type="text" name="nom" value="'.$fila['nom'].'"><br>';
					echo "<p>nick</p>";
					echo '<input type="text" name="nick" value="'.$fila['nick'].'"><br>';
					echo "<p>contrasenya</p>";
					echo '<input type="text" name="contrasenya" value="'.$fila['contrasenya'].'"><br>'; 
				}
			?>
		
		<br>
		
		<input type="submit" value="editar">
	</form>
	
</body>
</html>