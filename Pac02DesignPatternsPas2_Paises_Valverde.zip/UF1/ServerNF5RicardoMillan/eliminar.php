<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	

  	//make sure our recently created database is the active one
	mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

	$query='SELECT title FROM book';
	$resultado=mysqli_query($db, $query);
	mysqli_query($db,$query) or die (mysqli_error($db));

	?>
	<form action="confirmacion.php" method="post">
		<select name="title" id="">
			<p>QUE LIBRO QUIERES ELIMINAR</p>
			<?php 
				while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
					echo "<option value=".$fila['title'].">".$fila['title']."</option>";
				}
			?>
		</select>
		<input type="submit">
	</form>
</body>
</html>