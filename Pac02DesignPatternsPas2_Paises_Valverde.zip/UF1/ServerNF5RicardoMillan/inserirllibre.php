<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
		
		$db = mysqli_connect('localhost', 'root', 'root') or 
    	die ('Unable to connect. Check your connection parameters.');
	
    	//make sure our recently created database is the active one
		mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

		$query='SELECT name FROM people;';


		$resultado=mysqli_query($db, $query);
		$fecha=date('Y');


		echo '<form method="post" action="validate.php">';
			echo "<p> Quien es el autor del libro";
			echo '<select name="name" id="name">';
				while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
					echo "<option value=".$fila['name'].">".$fila['name']."</option>";
				}
			echo '</select>';
			echo "Titulo del libro";
			echo '<input type="text" name="title" id="title">';
			echo 'ISBN:';
			echo '<input type="text" name="isbn" id="isbn">';
			echo "</p>";
			echo '<input type="hidden" id="fecha" name="fecha" value="'.$fecha.'">';
			echo '<input type="hidden" id="visit" name="visit" value="0">';
			echo '<input type="submit" value="enviar datos">';

			
		echo '</form>';

	?>
</body>
</html>