<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		td{
			border: solid 1px black;
		}
		/*azul#7EAAFC*/
		/*verde #8BFF96*/
	</style>
</head>
<body>
	<?php
		$db = mysqli_connect('localhost', 'root', 'root') or 
   		 die ('Unable to connect. Check your connection parameters.');
	
  		//make sure our recently created database is the active one
		mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

		$consulta='SELECT * FROM book';

		$resultado=mysqli_query($db, $consulta);
		$stilo="";
		$cont=0;
		echo "<table>";
		while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
			if($cont%2==0){
        		$stilo="#7EAAFC";
        	}
        	else{
        		$stilo="#8BFF96";
        	}
        		echo "<tr style='background-color: ".$stilo." '>";
        		echo "<td>".$fila['idBook']."</td><td>".$fila['isbn']."</td><td>".$fila['author']."</td><td>".$fila['title']."</td><td>".$fila['visit']."</td><td>".$fila['year']."</td>";
        		echo "</tr>";
        		echo "<br>";
        		$cont++;
        	}

		echo "</table>";

	?>
</body>
</html>