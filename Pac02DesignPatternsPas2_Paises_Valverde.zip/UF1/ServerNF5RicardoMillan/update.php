<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	

  	//make sure our recently created database is the active one
	mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));

	$title=$_POST['title'];
	$autor=$_POST['author'];
	$isbn=$_POST['isbn'];

	echo $_SESSION['cambiarEste'];
	echo $title;

	$query='SELECT idBook FROM BOOK WHERE title like "'.$_SESSION['cambiarEste'].'%"';
	$resultado=mysqli_query($db, $query);
	mysqli_query($db,$query) or die (mysqli_error($db));

	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
		$idBook=$fila['idBook'];
	} 

	echo $idBook;

	$query3='SELECT idPeople from people where name like "'.$autor.'%"';

	$resultado3=mysqli_query($db, $query3);
	mysqli_query($db,$query3) or die (mysqli_error($db));

	while(($fila=mysqli_fetch_array($resultado3, MYSQLI_ASSOC))==true){
		$idautor=$fila['idPeople'];
	} 

	$query2='UPDATE book SET isbn = "'.$isbn.'", author = "'.$idautor.'", title = "'.$title.'" WHERE idBook = '.$idBook;


	$resultado2=mysqli_query($db, $query2);
	mysqli_query($db,$query2) or die (mysqli_error($db));





?>