<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
	
	
	$name = $_POST['name'];
	$titulo =$_POST['title'];
	$fecha=$_POST['fecha'];
	$visit=$_POST['visit'];
	$isbn=$_POST['isbn'];

	

	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
	
    //make sure our recently created database is the active one
	mysqli_select_db($db,'BookWeb') or die(mysqli_error($db));


	$query='SELECT idPeople FROM people WHERE name like "'.$name.'"';
	$resultado=mysqli_query($db, $query);

	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
		$query2='INSERT INTO book (isbn, author, title, visit, year)
			VALUES("'.$isbn.'", '.$fila['idPeople'].', "'.$titulo.'", '.$visit.', '.$fecha.')';

		mysqli_query($db,$query2) or die (mysqli_error($db));
	}
	echo "Se han insertado los datos";

	echo "<br><a href='inserirllibre.php'>Quieres insertar otro libro?</a>";
	echo "<br><a href='listado.php'>Quieres ver los resultados?</a>";
	

	?>

</body>
</html>