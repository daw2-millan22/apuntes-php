<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php

		$db = mysqli_connect('localhost', 'root', 'root') or die ('Unable to connect. Check your connection parameters.');
		
		
		$query = 'CREATE DATABASE IF NOT EXISTS prova01';
		mysqli_query($db,$query) or die(mysqli_error($db));
		
		mysqli_select_db($db,'prova01') or die(mysqli_error($db));
		
		//create the movie table
		$query = 'CREATE TABLE trabajadores (
		        trabajador_id        INTEGER UNSIGNED  NOT NULL AUTO_INCREMENT, 
		        last_name      VARCHAR(255)      NOT NULL,
		        first_name      VARCHAR(255)      NOT NULL,
		        hire_date      date     NOT NULL,  
		        job_title VARCHAR(255)  NOT NULL DEFAULT 0,

		        PRIMARY KEY (trabajador_id)
		    ) 
		    ENGINE=MyISAM';
  		mysqli_query($db,$query) or die (mysqli_error($db));

  		

  		$sql1 = "INSERT INTO trabajadores (last_name, first_name, hire_date, job_title)
   		 VALUES 
      	('Smith', 'James', '2016/03/01', 'Staff Account'),
      	('Williams', 'Roberta', '2004/02/07', 'Sr. Software Engineer'),
      	('Weinberg', 'Jeff', '2007/01/02', 'Human Resource Manger'),
      	('Franklin', 'Victoria', '2010/07/02', 'Operations Manager'),
      	('Amstrong', 'Williams', '2009/09/09', 'Database Administrator')";

      	mysqli_query($db,$sql1) or die (mysqli_error($db));

	?>
</body>
</html>