<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		tr, td{
			border: solid 1px;
			border-collapse: inherit;
		}
	</style>
</head>
<body>
	<?php

		$servidor="localhost";
        $dbNombre="prova01";
        $usuario="root";
        $contrasenia="root";

        $conexion=mysqli_connect($servidor, $usuario, $contrasenia)or die('no has conectado a la base de datos');

        mysqli_select_db($conexion, $dbNombre) or die(mysqli_error($conexion));

        $consulta='SELECT * FROM trabajadores';

        $resultado=mysqli_query($conexion, $consulta);


        echo "<table>";

        	while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){
        		echo "<tr>";
        		echo "<td>".$fila['trabajador_id']."</td><td>".$fila['first_name']."</td><td>".$fila['last_name']."</td><td>".$fila['hire_date']."</td><td>".$fila['job_title']."</td>";
        		echo "</tr>";
        	}

        echo "</table>";
	?>
</body>
</html>