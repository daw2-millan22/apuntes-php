<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	
	<?php
		$nombre= $_POST['first_name'];
		$apellido=$_POST['last_name'];
		$fecha=$_POST['hire_date'];
		$titulo=$_POST['job_title'];

		
		$db = mysqli_connect('localhost', 'root', 'root') or die ('No has conseguido hacer conexion');

		mysqli_select_db($db,'prova01') or die(mysqli_error($db));

		$insert= "INSERT INTO trabajadores (first_name, last_name, hire_date, job_title)
		 VALUES('$nombre', '$apellido', '$fecha', '$titulo')";

		mysqli_query($db,$insert) or die(mysqli_error($db));
		if(mysqli_error($db)==null){
			echo "se han introducido los datos";
		}	
		
		setcookie("first_name", $_POST['first_name'], time() + 6000);
		setcookie("last_name", $_POST['last_name'], time() + 6000);

		echo "<a href='02cookie.php'>mira el mensaje</a><br>";
		echo "<a href='05form.html'>introduce otro</a><br>";
		echo "<a href='04llistat.php'>mirar tabla</a>";
	?>
</body>
</html>