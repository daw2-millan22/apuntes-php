<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "prova01";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql1 = "INSERT INTO trabajadores (last_name, first_name, hire_date, job_title)
   		 VALUES 
      	('Smith', 'James', '2016/03/01', 'Staff Account'),
      	('Williams', 'Roberta', '2004/02/07', 'Sr. Software Engineer'),
      	('Weinberg', 'Jeff', '2007/01/02', 'Human Resource Manger'),
      	('Franklin', 'Victoria', '2010/07/02', 'Operations Manager'),
      	('Amstrong', 'Williams', '2009/09/09', 'Database Administrator')";


if ($conn->query($sql1) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql1 . "<br>" . $conn->error;
}
$conn->close();
?>