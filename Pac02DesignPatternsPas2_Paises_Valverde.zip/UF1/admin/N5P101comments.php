<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Documet</title>
</head>
<body>
<ol>	
	<li>Your first form</li>
	<li>Setting Up the Environment</li>
	<li>Inserting and Editing a Record</li>
	<li>Cascade Delete</li>
	<li>Driving the User Input</li>
	<li>One Form, Multiple Processing</li>
	<li> Radio INPUT Element</li>
	<li>Multiple Submit Buttons</li>
	<li>Basic Input Testing</li>
	<li>Ternary Operator</li>
</ol>
<p>Un 8 y un 7.</p>

<p>La nota que pongo es un 7</p>

<p>Bona la explicacio d'aquesta practica</p>
</body>
</html>