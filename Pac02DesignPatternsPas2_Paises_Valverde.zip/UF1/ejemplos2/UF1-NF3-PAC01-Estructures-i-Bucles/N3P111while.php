<?php
$num = 0;
while ($num < 5) {
$num = $num + 1;
echo $num;
echo "<br/>";
}
?>
