<?php
$num = 0;
do{
  $num = $num + 1;
  echo $num;
  echo "< br/>";
}while ($num<5);
?>
