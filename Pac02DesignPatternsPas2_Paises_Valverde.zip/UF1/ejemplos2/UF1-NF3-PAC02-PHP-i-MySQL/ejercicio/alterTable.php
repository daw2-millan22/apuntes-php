<?php 


	$db = mysqli_connect('localhost', 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
    
    //make sure our recently created database is the active one
	mysqli_select_db($db,'moviesite') or die(mysqli_error($db));

    $query = '	ALTER TABLE movie 
      			ADD CONSTRAINT FK_moviepeoplev2
      			FOREIGN KEY  (movie_year) REFERENCES people(poeple_fullname)';
	$result = mysqli_query($db,$query) or die(mysqli_error($db));

	

?>