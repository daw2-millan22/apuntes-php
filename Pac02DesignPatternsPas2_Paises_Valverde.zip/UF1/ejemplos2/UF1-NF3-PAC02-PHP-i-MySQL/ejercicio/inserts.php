<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "moviesite";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql  = 'INSERT INTO people
        (people_fullname, people_isactor, people_isdirector)
    VALUES
        ("Benito Camelas", 1, 8),("Ricardo Millán", 6, 1),("Rosa Melano", 0, 1)';

$sql1 = "INSERT INTO movie (movie_name, movie_type, movie_year, movie_leadactor, movie_director)
    VALUES 
      ('Celda 212', 1, 2008, 8, 7),('300', 2, 2007, 5, 7), ('Otra pelicula chula', 2, 2021, 4, 2)";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
if ($conn->query($sql1) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql1 . "<br>" . $conn->error;
}

$conn->close();
?>