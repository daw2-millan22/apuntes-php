<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        td{
            border: solid 1px;
            border-collapse: inherit;
            text-align: center;
            margin: auto;
        }
    </style>

</head>
<body>
    <?php

        $servidor="localhost";
        $dbNombre="moviesite";
        $usuario="root";
        $contrasenia="root";

        $conexion=mysqli_connect($servidor, $usuario, $contrasenia)or die('no has conectado a la base de datos');

        mysqli_select_db($conexion, $dbNombre) or die(mysqli_error($conexion));

        $consulta="SELECT movie_name, people_fullname FROM movie, people WHERE people_id=movie_leadactor";

        $resultado=mysqli_query($conexion, $consulta);

        echo "<table>";
        while(($fila=mysqli_fetch_array($resultado, MYSQLI_ASSOC))==true){

            echo "<tr><td>";
            echo $fila['movie_name']." por " .$fila['people_fullname'];
            echo "</td></tr>";
            echo "<br><br>";
        }
        echo "<table>";
    ?>  
</body>
</html>
