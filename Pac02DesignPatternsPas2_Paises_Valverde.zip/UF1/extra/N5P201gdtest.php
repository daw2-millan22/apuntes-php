<?php
echo '<pre>';
print_r(gd_info());
echo '</pre>';
?>