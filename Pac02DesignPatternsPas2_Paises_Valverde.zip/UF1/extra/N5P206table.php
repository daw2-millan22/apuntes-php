<?php
$db = mysqli_connect('localhost', 'bp6am', 'bp6ampass') or 
    die ('Unable to connect. Check your connection parameters.');
mysqli_select_db($db, 'moviesite') or die($db, $query($db));

//create the images table
$query = 'ALTER TABLE images DROP COLUMN image_filename';

mysqli_query($db, $query) or die ($db, $query($db));

echo 'Images table successfully updated.';
?>
