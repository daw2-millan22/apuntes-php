<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Documet</title>
</head>
<body>
<ol>	
	<li>Descarregar codi de GitHub des de Codenvy</li>
	<li>Comprovar les dades de Mysql per consola</li>
	<li>Corregir codi "Unable to connect"</li>
	<li>Corregir codi "Unknown column"</li>
	<li> Mostrar les dades de la base de dades</li>
	<li>Configurar les variables GET per fer la paginaci� i el cercador.</li>
	<li> Corregir codi afegint els comodins % per fer la cerca.</li>
	<li>Calcular el total de dades a cercar.</li>
	<li>Modificar el nombre de registres per p�gina</li>
	<li>Entrega de la practica</li>
</ol>
<p>Un 5 y un 6.</p>

<p>La nota que pongo es un 5</p>

<p>Podria explicar un poco mas graficamente los ejercicios</p>
</body>
</html>