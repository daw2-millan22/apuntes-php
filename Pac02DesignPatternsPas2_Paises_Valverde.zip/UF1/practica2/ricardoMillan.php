</head>
<body>
	<?php 
	echo "lo mejor que he aprendido en este documento es:<br>-aprender a verificar datos<br>-pasar datos de un link a otro<br>-'la funcion SESSION' <br>-'la funcion GET'<br>-'la funcion POST' <br>-'la funcion COOKIE'<br>-Aprendí a verificar variables nulas y darles valores por defecto si es que son nulas<br>-Aprendi funciones que nos dicen la fecha<br>-aprendi a usar un poco mas github<br>-aprendi que se pueden extraer algunos datos por la url";
?>
</body>


