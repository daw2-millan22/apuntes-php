<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Documet</title>
</head>
<body>
<ol>	
	<li>Descarregar codi de GitHub des de Codenvy</li>
	<li>Creating a Table</li>
	<li>Improving Your Table</li>
	<li>Adding Links to the Table</li>
	<li>Adding Data to the Table</li>
	<li>Creating and Filling a Review Table.</li>
	<li> Displaying Details and Reviews on a Table</li>
	<li>Calcular el total de dades a cercar.</li>
	<li>Modificar el nombre de registres per p�gina</li>
	<li>Entrega de la practica</li>
</ol>
<p>Un 6 y un 7.</p>

<p>La nota que pongo es un 6</p>

<p>Podria explicar un poco mas graficamente los ejercicios</p>
</body>
</html>