<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Documet</title>
</head>
<body>
<ol>	
	<li>Adapting Your Script to the User Input</li>
	<li>How It Works</li>
	<li>function returns true if the variable has been set,</li>
	<li>trim()on the field�s content to eliminate any space</li>
	<li>Checking Dates and Numbers</li>
	<li>Entering letters in the rating field.</li>
	<li> Using the mktime()function</li>
	<li>USE The explode()</li>
	<li>Basic Input Testing</li>
	<li>Entregar la practica</li>
</ol>
<p>Un 7 y un 8.</p>

<p>La nota que pongo es un 7</p>

<p>Bona la explicacio d'aquesta practica</p>
</body>
</html>