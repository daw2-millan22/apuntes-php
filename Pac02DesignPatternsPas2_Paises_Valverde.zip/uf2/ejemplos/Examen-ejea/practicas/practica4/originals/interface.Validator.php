<?php
  interface Validator {
    public function validate();
  }
?>
