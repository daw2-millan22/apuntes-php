<?php
require_once("observable.php");
require_once("abstract_widget.php");

$dat = new DataSource();
$widgetA = new BasicWidget();
$widgetB = new FancyWidget();
$widgetC = new MenuWidget();

$dat->addObserver($widgetA);
$dat->addObserver($widgetB);
$dat->addObserver($widgetC);

$dat->addRecord("Coche", "$12.95", 1955,"Ricardo");
$dat->addRecord("cajón", "$13.95", 2003,"Alberto");
$dat->addRecord("Guitarrilla", "$100.95", 1945,"Antoñito");
$dat->addRecord("Trompetilla", "$120.95", 1999,"Jorgito");

$widgetA->draw();
$widgetB->draw();
$widgetC->draw();



?>
