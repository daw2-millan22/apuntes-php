<?php 
	
	require_once("modelo/classClima.php");
	require_once("modelo/classGeografia.php");

	$clima=new Clima();

	$matrizProduct=$clima->getClima();

	$geografia=new Geografia();

	$matrizGeografia=$geografia->getGeografia();

	
	require_once("vista/widget.php");




?>