<?php




	class Clima{

		private $db;

		private $clima;

		public function __construct(){

			require_once("modelo/conectar.php");

			$this->db=Conectar::conexion();

			$this->clima=array();

		}

		public function getClima(){

			$consulta=$this->db->query("SELECT * FROM clima");


			while ($filas=$consulta->fetch(PDO::FETCH_ASSOC)) {

				$this->clima[]=$filas;
				// code...
			}

			return $this->clima;

		}
	}
?>