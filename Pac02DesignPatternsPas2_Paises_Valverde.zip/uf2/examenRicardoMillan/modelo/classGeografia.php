<?php




	class Geografia{

		private $db;

		private $geografia;

		private $clima;

		public function __construct(){

			require_once("modelo/conectar.php");

			$this->db=Conectar::conexion();

			$this->geografia=array();

			$this->clima=array();



		}

		public function getGeografia(){

			$consulta=$this->db->query("SELECT * FROM geografia");


			while ($filas=$consulta->fetch(PDO::FETCH_ASSOC)) {

				$this->geografia[]=$filas;
				// code...
			}

			return $this->geografia;

		}

	}
?>