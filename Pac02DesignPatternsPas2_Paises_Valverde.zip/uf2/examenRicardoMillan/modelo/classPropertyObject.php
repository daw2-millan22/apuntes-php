classPropertyObject.php
