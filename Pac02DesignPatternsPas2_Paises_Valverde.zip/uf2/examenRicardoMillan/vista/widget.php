
<?php
	echo "CLIMA <br>";
	foreach ($matrizProduct as $registro ) {
		// code...

		echo $registro["tipus"] . "<br>" ;
	}
	echo "<br>";


	echo "GEOGRAFIA <br>";

	foreach ($matrizGeografia as $registro ) {
		// code...

		echo $registro["nom"] . "<br>" ;
	}
	echo "<br>";
	echo "<br>";
	

?>
