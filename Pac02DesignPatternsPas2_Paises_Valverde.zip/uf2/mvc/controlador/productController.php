productController
<?php 
	
	require_once("modelo/productModel.php");

	$producto=new ProductModel();

	$matrizProduct=$producto->getProduct();
	require_once("vista/productView.php");




?>