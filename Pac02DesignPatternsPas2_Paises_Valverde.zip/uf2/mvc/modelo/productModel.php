productModel
<?php 
	class ProductModel{

		private $db;

		private $productos;

		public function __construct(){

			require_once("modelo/conectar.php");

			$this->db=Conectar::conexion();

			$this->productos=array();

		}

		public function getProduct(){

			$consulta=$this->db->query("SELECT * FROM PRODUCTOS");


			while ($filas=$consulta->fetch(PDO::FETCH_ASSOC)) {

				$this->productos[]=$filas;
				// code...
			}

			return $this->productos;

		}
	}

?> 