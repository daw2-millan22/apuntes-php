<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

	<style>
		td{
			border: 1px dotted darkred;
		}
	</style>
</head>
<body>

			<table>
				<tr>
					<td>
						NOMBRE DEL ARTICULO
			
<?php
	
	foreach ($matrizProduct as $registro ) {
		// code...

		echo $registro["NOMBREARTICULO"] . "</td></tr>" ;
	}

?>
</body>
</html>