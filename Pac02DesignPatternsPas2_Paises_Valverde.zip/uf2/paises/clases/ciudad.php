<?php
	
class Ciudad extends AbstractZona {
  function __construct($nombre, $superficie, $poblacion) {
    parent::setNombre($nombre);
    parent::setSuperficie($superficie);
    parent::setPoblacion($poblacion);
  }
}
?>