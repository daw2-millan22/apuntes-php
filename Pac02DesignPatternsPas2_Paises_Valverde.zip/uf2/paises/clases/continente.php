<?php
	
class Continente extends AbstractZona {
  function __construct($nombre, $superficie, $poblacion) {
    parent::setNombre($nombre);
    parent::setSuperficie($superficie);
    parent::setPoblacion($poblacion);
  } 
  public function sumarPoblacion(){

    $poblacioTotal = 0;
  
    if ($this->hasChildren()) {
      foreach($this->getzonas() as $zona) {
      $poblacioTotal = $poblacioTotal + $zona ->sumarPoblacion();
      }
    } 

    return $poblacioTotal;
  }


  public function sumarSuperficie(){

    $superficietotal = 0;
  
    if ($this->hasChildren()) {
      foreach($this->getzonas() as $zona) {
      $superficietotal = $superficietotal + $zona ->sumarSuperficie();
      }
    } 

    return $superficietotal;
  }     
}
?>