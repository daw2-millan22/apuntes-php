<?php

abstract class AbstractZona {
  
  private $nombre;
  private $superficie;
  private $poblacion;
  private $zona = array();

  
  public function add(AbstractZona $zona) {
     array_push($this->zona, $zona);
  }
  
  public function remove(AbstractZona $zona) {
     array_pop($this->zona);
  }
        
  public function hasChildren() {
    return (bool)(count($this->zona) > 0);
  }
    
  public function getChild($i) {
    return $this->zona[i];
  }
  public function getzonas() {
    return $this->zona;
  }
    
  public function getDescription() {
    echo $this->getNombre(). " - " .  $this->getSuperficie() . " - " . $this->getPoblacion();
    if ($this->hasChildren()) {
      echo " :<br>";
      foreach($this->zona as $zona) {
         echo "<table cellspacing=5 border=0><tr><td>&nbsp;&nbsp;&nbsp;</td><td>-";
         $zona->getDescription();
         echo "</td></tr></table>";
      }        
    }
  }







 public function setNombre($nombre) {
   $this->nombre = $nombre;
 }
  
 public function getNombre() {
   return $this->nombre;
 }
         
 public function setSuperficie($superficie) {
    $this->superficie = $superficie;
 }

 public function getSuperficie() {
   return $this->superficie;
  }
  public function getZona() {
   return $this->zona;
  }

 public function setPoblacion($poblacion) {
    $this->poblacion = $poblacion;
 }

 public function getPoblacion() {
   return $this->poblacion;
  }
}
	include 'continente.php';
	include 'pais.php';
	include 'ciudad.php';
	include 'pueblo.php';

?>