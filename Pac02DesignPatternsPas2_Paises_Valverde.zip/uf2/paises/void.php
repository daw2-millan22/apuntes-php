<?php
	include 'clases/zona.php';
		
	$ciudad1=new Ciudad("Badalona", 1000, 100000);
	$ciudad2=new Ciudad("Barcelona", 5000, 200000000);
	$ciudad3=new Ciudad("Madrid", 7000, 1);

	
	$pueblo1=new Pueblo("Maçanet de la Selva", 100, 2000);
	$pueblo2=new Pueblo("Belalcazar", 20, 500);
	$pueblo3=new Pueblo("Hinojosa del duque", 30, 600);

	$pais1=new Pais("España", 4654651, 654654);


	$pais1->add($ciudad3);
	$pais1->add($pueblo2);
	$pais1->add($pueblo3);

	$pais2=new Pais("Catalunya", 5146, 785641);

	$pais2->add($ciudad1);
	$pais2->add($ciudad2);
	$pais2->add($pueblo1);


	$pais1->getDescription();

	$pais2->getDescription();

	$continente=new Continente("Europa", 21, 54);

	$continente->add($pais1);
	$continente->add($pais2);

	$continente->getDescription();

	

	echo "Poblacion Total: <p>";
	echo $continente->getNombre(). ": ";
	echo $continente->sumarPoblacion();
	echo "<br>";
	echo $pais1->getNombre() . ": ";
	echo $pais1->sumarPoblacion();
	echo "<br>";
	echo $pais2->getNombre() . ": ";
	echo $pais2->sumarPoblacion();
	echo "<br>";

	echo "<br>Superficie Total: <p>";
	echo $continente->getNombre(). ": ";
	echo $continente->sumarSuperficie();
	echo "<br>";
	echo $pais1->getNombre() . ": ";
	echo $pais1->sumarSuperficie();
	echo "<br>";
	echo $pais2->getNombre() . ": ";
	echo $pais2->sumarSuperficie();








	
?>